const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();
const { pool, initializeDatabase } = require('./db');

// Rest of the code remains the same...
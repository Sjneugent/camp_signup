const express = require('express');
const cors = require('cors');
const app = express();
const port = 4000;

app.use(cors());
app.use(express.json());

const registrations = [];
const CLASSES = [
  "Art", "Music", "Science", "Math", "Drama", "Sports", "Coding", 
  "Cooking", "Robotics", "Dance", "Chess"
];

app.get('/api/classes', (req, res) => {
  res.json(CLASSES);
});

app.post('/api/register', (req, res) => {
  const { parentName, parentEmail, students } = req.body;
  if (!parentName || !parentEmail || !Array.isArray(students) || students.length === 0) {
    return res.status(400).json({ error: "Invalid registration data." });
  }
  for (const student of students) {
    if (!student.name || !Array.isArray(student.classes) || student.classes.length !== 3) {
      return res.status(400).json({ error: "Each student must have a name and select exactly 3 classes." });
    }
  }
  const reg = { parentName, parentEmail, students, timestamp: Date.now() };
  registrations.push(reg);
  res.json({ success: true });
});

app.get('/api/registrations', (req, res) => {
  res.json(registrations);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});